﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using LinqToTwitter;

namespace Twitter
{
    class Program
    {

        static void Main(string[] args)
        {
            Console.WriteLine("Please enter account:");
            string account = Console.ReadLine();
            RunCrawlingOperation(account);

            Console.Write("\nPress any key to close console window...");
            Console.ReadKey(true);
        }

        public static void RunCrawlingOperation(string account)
        {
            while (true)
            {
                Console.WriteLine("");
                try
                {
                    Console.WriteLine("____ ____Crawling twitter account '" + account + "'");
                    Task searchTask = DoPagedSearchAsync(account);
                    searchTask.Wait();
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message + "    " + ex.StackTrace);
                    Console.WriteLine("____ ____ ____Sleeping 5 minutes!!!!");
                    Thread.Sleep(300000);

                    Console.WriteLine("____ ____Crawling twitter account '" + account + "'");
                    Task searchTask = DoPagedSearchAsync(account);
                    searchTask.Wait();
                }

                Console.WriteLine("");
                Console.WriteLine("Program will rerun in 3 minutes!!!");
                Thread.Sleep(180000);
                RunCrawlingOperation(account);
            }
        }

        static IAuthorizer DoUserAuth()
        {
            var auth = new ApplicationOnlyAuthorizer()
            {
                CredentialStore = new InMemoryCredentialStore
                {
                    ConsumerKey = "gkYMHrGMcFrPcP9wO5gzWaTFa",
                    ConsumerSecret = "UpArcdhNVoOCp56NdgF576uir44EmewPCUi5WawEv4A5AioiVk"
                },
            };
            return auth;
        }

        static async Task DoPagedSearchAsync(string account)
        {
            try
            {
                var auth = DoUserAuth();
                await auth.AuthorizeAsync();
                var twitterCtx = new TwitterContext(auth);


                List<Status> searchResponse = await (from tweet in twitterCtx.Status
                                                     where tweet.Type == StatusType.User &&
                                                        tweet.ScreenName == account &&
                                                        tweet.Count == 100
                                                     //&&
                                                     //tweet.SinceID == sinceID
                                                     // in each call we are getting 200 tweet
                                                     select tweet)
                                    .ToListAsync();

                foreach (var status in searchResponse)
                {
                    Console.WriteLine(status.Text);
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }

        }

    }
}
